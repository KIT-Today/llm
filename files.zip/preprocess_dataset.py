"""
한국형 번아웃 감정 분류 데이터셋 전처리 스크립트
- 감성대화 말뭉치 (JSON)
- 연속적 대화 데이터셋 (XLSX)
→ 4개 번아웃 카테고리로 매핑하여 학습용 CSV 생성
"""

import json
import pandas as pd
import re
from pathlib import Path
from collections import Counter
import argparse


# ============================================================
# 감정 코드 → 번아웃 카테고리 매핑
# ============================================================

# 감성대화 말뭉치 60개 감정 코드 매핑
# 참고: 한국형 번아웃 4요인 (정서적고갈, 좌절압박, 부정적대인관계, 자기비하)

EMOTION_CODE_MAPPING = {
    # 정서적_고갈: 감정적 소진, 무기력, 우울, 슬픔
    "E20": "정서적_고갈",  # 슬픔
    "E21": "정서적_고갈",  # 실망
    "E22": "정서적_고갈",  # 비통함
    "E23": "정서적_고갈",  # 후회
    "E24": "정서적_고갈",  # 우울
    "E25": "정서적_고갈",  # 마비됨
    "E40": "정서적_고갈",  # 상처
    "E41": "정서적_고갈",  # 희생됨
    "E45": "정서적_고갈",  # 고립됨
    "E53": "정서적_고갈",  # 외로움
    "E58": "정서적_고갈",  # 한심함 (자기향 → 고갈)
    
    # 좌절_압박: 불안, 초조, 압박감, 스트레스
    "E12": "좌절_압박",    # 두려움
    "E13": "좌절_압박",    # 걱정
    "E16": "좌절_압박",    # 초조함
    "E17": "좌절_압박",    # 조바심
    "E27": "좌절_압박",    # 당혹
    "E28": "좌절_압박",    # 난처함
    "E29": "좌절_압박",    # 혼란
    "E30": "좌절_압박",    # 불안
    "E31": "좌절_압박",    # 스트레스
    "E32": "좌절_압박",    # 취약함
    "E35": "좌절_압박",    # 당혹스러움
    "E50": "좌절_압박",    # 당황
    
    # 부정적_대인관계: 분노, 짜증, 배신감, 대인갈등
    "E10": "부정적_대인관계",  # 분노
    "E11": "부정적_대인관계",  # 툴툴대는
    "E14": "부정적_대인관계",  # 끔찍한
    "E15": "부정적_대인관계",  # 악의적인
    "E18": "부정적_대인관계",  # 성가심
    "E19": "부정적_대인관계",  # 짜증
    "E33": "부정적_대인관계",  # 괴로워하는
    "E34": "부정적_대인관계",  # 질투
    "E38": "부정적_대인관계",  # 회의적인
    "E42": "부정적_대인관계",  # 배신당한
    "E43": "부정적_대인관계",  # 억울한
    "E44": "부정적_대인관계",  # 충격받은
    "E46": "부정적_대인관계",  # 속상한
    "E47": "부정적_대인관계",  # 억울함
    "E48": "부정적_대인관계",  # 환멸
    "E51": "부정적_대인관계",  # 죄책감
    "E52": "부정적_대인관계",  # 부끄러움
    
    # 자기비하: 자기비판, 열등감, 무능감
    "E26": "자기비하",    # 염세적
    "E36": "자기비하",    # 눈물이 나는
    "E37": "자기비하",    # 느긋 (반전 코딩 제외)
    "E39": "자기비하",    # 회한
    "E49": "자기비하",    # 버려진
    "E54": "자기비하",    # 열등감
    "E55": "자기비하",    # 죄책감
    "E56": "자기비하",    # 부끄러움
    "E57": "자기비하",    # 혐오 (자기향)
    
    # 제외: 긍정 감정 및 중립
    # E60~E69: 대부분 긍정 감정 (만족, 신뢰, 기쁨 등)
}

# 연속적 대화 데이터셋 7감정 → 4카테고리 매핑
EMOTION_7_MAPPING = {
    "슬픔": "정서적_고갈",
    "공포": "좌절_압박",
    "분노": "부정적_대인관계",
    "혐오": "부정적_대인관계",  # 맥락에 따라 자기비하일 수도
    # 제외
    "행복": None,
    "중립": None,
    "놀람": None,  # 맥락 의존적이라 제외
}


# ============================================================
# 텍스트 전처리 함수
# ============================================================

def clean_text(text: str) -> str:
    """텍스트 정제"""
    if not text or not isinstance(text, str):
        return ""
    
    # 공백 정규화
    text = re.sub(r'\s+', ' ', text).strip()
    
    # 너무 짧은 텍스트 제외
    if len(text) < 5:
        return ""
    
    return text


def extract_utterances_from_dialog(talk_content: dict) -> list:
    """대화에서 사용자 발화(HS01, HS02, HS03) 추출"""
    utterances = []
    for key in ['HS01', 'HS02', 'HS03']:
        text = talk_content.get(key, '')
        cleaned = clean_text(text)
        if cleaned:
            utterances.append(cleaned)
    return utterances


# ============================================================
# 데이터셋 처리 함수
# ============================================================

def process_emotion_dialog(json_path: str) -> pd.DataFrame:
    """
    감성대화 말뭉치 처리
    Returns: DataFrame with columns [text, label, emotion_code, source]
    """
    print(f"\n[1] 감성대화 말뭉치 처리 중: {json_path}")
    
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    print(f"    - 총 대화 수: {len(data)}")
    
    records = []
    emotion_stats = Counter()
    
    for item in data:
        emotion_code = item['profile']['emotion']['type']
        emotion_stats[emotion_code] += 1
        
        # 매핑되지 않는 감정은 스킵 (긍정 감정 등)
        if emotion_code not in EMOTION_CODE_MAPPING:
            continue
        
        label = EMOTION_CODE_MAPPING[emotion_code]
        utterances = extract_utterances_from_dialog(item['talk']['content'])
        
        for text in utterances:
            records.append({
                'text': text,
                'label': label,
                'emotion_code': emotion_code,
                'source': 'emotion_dialog'
            })
    
    df = pd.DataFrame(records)
    
    print(f"    - 번아웃 관련 추출: {len(df)} 발화")
    print(f"    - 라벨 분포:")
    for label, count in df['label'].value_counts().items():
        print(f"      {label}: {count}")
    
    return df


def process_continuous_dialog(xlsx_path: str) -> pd.DataFrame:
    """
    연속적 대화 데이터셋 처리
    Returns: DataFrame with columns [text, label, emotion_code, source]
    """
    print(f"\n[2] 연속적 대화 데이터셋 처리 중: {xlsx_path}")
    
    df_raw = pd.read_excel(xlsx_path)
    print(f"    - 원본 shape: {df_raw.shape}")
    
    # 컬럼 구조 파악 (첫 행이 헤더인 경우 처리)
    # Unnamed: 0 = dialog #, Unnamed: 1 = 발화, Unnamed: 2 = 감정
    records = []
    
    for idx, row in df_raw.iterrows():
        if idx == 0:  # 헤더 행 스킵
            continue
        
        text = str(row.iloc[1]) if pd.notna(row.iloc[1]) else ""
        emotion = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""
        
        text = clean_text(text)
        if not text:
            continue
        
        # 감정 라벨 정제 (오타 처리)
        emotion = emotion.strip()
        if emotion in ['ㅍ', '분', 'ㅈ중립', '중림', '분ㄴ', 'ㄴ중립', '줄', '감정']:
            continue  # 오류 데이터 스킵
        
        # 매핑
        if emotion not in EMOTION_7_MAPPING:
            continue
        
        label = EMOTION_7_MAPPING.get(emotion)
        if label is None:  # 행복, 중립, 놀람 등 제외
            continue
        
        records.append({
            'text': text,
            'label': label,
            'emotion_code': emotion,
            'source': 'continuous_dialog'
        })
    
    df = pd.DataFrame(records)
    
    print(f"    - 번아웃 관련 추출: {len(df)} 발화")
    print(f"    - 라벨 분포:")
    for label, count in df['label'].value_counts().items():
        print(f"      {label}: {count}")
    
    return df


# ============================================================
# 메인 처리 및 저장
# ============================================================

def merge_and_save(df1: pd.DataFrame, df2: pd.DataFrame, output_dir: str):
    """데이터 병합 및 저장"""
    print("\n[3] 데이터 병합 및 저장")
    
    # 병합
    df_all = pd.concat([df1, df2], ignore_index=True)
    print(f"    - 총 데이터: {len(df_all)}")
    
    # 중복 제거
    before_dedup = len(df_all)
    df_all = df_all.drop_duplicates(subset=['text'], keep='first')
    print(f"    - 중복 제거: {before_dedup} → {len(df_all)}")
    
    # 라벨 분포 확인
    print(f"\n    - 최종 라벨 분포:")
    label_counts = df_all['label'].value_counts()
    for label, count in label_counts.items():
        print(f"      {label}: {count} ({count/len(df_all)*100:.1f}%)")
    
    # 출력 디렉토리 생성
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    # 전체 데이터 저장
    all_path = output_path / "burnout_all.csv"
    df_all.to_csv(all_path, index=False, encoding='utf-8-sig')
    print(f"\n    - 전체 데이터 저장: {all_path}")
    
    # Train/Val/Test 분할 (8:1:1)
    from sklearn.model_selection import train_test_split
    
    # Stratified split
    df_train, df_temp = train_test_split(
        df_all, test_size=0.2, random_state=42, stratify=df_all['label']
    )
    df_val, df_test = train_test_split(
        df_temp, test_size=0.5, random_state=42, stratify=df_temp['label']
    )
    
    # 저장
    train_path = output_path / "train.csv"
    val_path = output_path / "val.csv"
    test_path = output_path / "test.csv"
    
    df_train.to_csv(train_path, index=False, encoding='utf-8-sig')
    df_val.to_csv(val_path, index=False, encoding='utf-8-sig')
    df_test.to_csv(test_path, index=False, encoding='utf-8-sig')
    
    print(f"    - Train: {len(df_train)} → {train_path}")
    print(f"    - Val: {len(df_val)} → {val_path}")
    print(f"    - Test: {len(df_test)} → {test_path}")
    
    # 학습용 간소화 버전 (text, label만)
    df_simple = df_all[['text', 'label']].copy()
    simple_path = output_path / "burnout_dataset.csv"
    df_simple.to_csv(simple_path, index=False, encoding='utf-8-sig')
    print(f"    - 간소화 버전: {simple_path}")
    
    return df_all


def main():
    parser = argparse.ArgumentParser(description='번아웃 데이터셋 전처리')
    parser.add_argument('--data_dir', type=str, 
                        default=r'D:\Programming\Projects\Burnout\dataset',
                        help='데이터셋 루트 디렉토리')
    parser.add_argument('--output_dir', type=str,
                        default=r'D:\Programming\Projects\Burnout\dataset\processed',
                        help='출력 디렉토리')
    args = parser.parse_args()
    
    data_dir = Path(args.data_dir)
    
    # 파일 경로
    emotion_json = data_dir / "018.감성대화" / "Training_221115_add" / "라벨링데이터" / \
                   "감성대화말뭉치(최종데이터)_Training" / "감성대화말뭉치(최종데이터)_Training.json"
    continuous_xlsx = data_dir / "한국어 감정 정보가 포함된 연속적 대화 데이터셋" / \
                      "한국어_연속적_대화_데이터셋.xlsx"
    
    print("=" * 60)
    print("한국형 번아웃 감정 분류 데이터셋 전처리")
    print("=" * 60)
    
    # 처리
    df1 = process_emotion_dialog(str(emotion_json))
    df2 = process_continuous_dialog(str(continuous_xlsx))
    
    # 병합 및 저장
    df_final = merge_and_save(df1, df2, args.output_dir)
    
    print("\n" + "=" * 60)
    print("전처리 완료!")
    print("=" * 60)


if __name__ == "__main__":
    main()
