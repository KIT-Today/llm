"""
한국형 번아웃 감정 분류 모델 학습 스크립트
KoELECTRA-base-v3 파인튜닝
"""

import os
import argparse
import pandas as pd
import numpy as np
from pathlib import Path

import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    ElectraTokenizer,
    ElectraForSequenceClassification,
    TrainingArguments,
    Trainer,
    EarlyStoppingCallback
)
from sklearn.metrics import accuracy_score, f1_score, classification_report
import warnings
warnings.filterwarnings('ignore')


# ============================================================
# 설정
# ============================================================

MODEL_NAME = "monologg/koelectra-base-v3-discriminator"

LABEL2ID = {
    "정서적_고갈": 0,
    "좌절_압박": 1,
    "부정적_대인관계": 2,
    "자기비하": 3
}

ID2LABEL = {v: k for k, v in LABEL2ID.items()}


# ============================================================
# 데이터셋 클래스
# ============================================================

class BurnoutDataset(Dataset):
    """번아웃 감정 분류 데이터셋"""
    
    def __init__(self, csv_path: str, tokenizer, max_length: int = 128):
        self.df = pd.read_csv(csv_path)
        self.tokenizer = tokenizer
        self.max_length = max_length
        
        # 라벨 인코딩
        self.df['label_id'] = self.df['label'].map(LABEL2ID)
        
        print(f"Loaded {len(self.df)} samples from {csv_path}")
        print(f"Label distribution: {dict(self.df['label'].value_counts())}")
    
    def __len__(self):
        return len(self.df)
    
    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        text = str(row['text'])
        label = row['label_id']
        
        encoding = self.tokenizer(
            text,
            max_length=self.max_length,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].squeeze(0),
            'attention_mask': encoding['attention_mask'].squeeze(0),
            'labels': torch.tensor(label, dtype=torch.long)
        }


# ============================================================
# 메트릭 함수
# ============================================================

def compute_metrics(eval_pred):
    """평가 메트릭 계산"""
    predictions, labels = eval_pred
    predictions = np.argmax(predictions, axis=1)
    
    acc = accuracy_score(labels, predictions)
    f1_macro = f1_score(labels, predictions, average='macro')
    f1_weighted = f1_score(labels, predictions, average='weighted')
    
    return {
        'accuracy': acc,
        'f1_macro': f1_macro,
        'f1_weighted': f1_weighted
    }


# ============================================================
# 메인 학습 함수
# ============================================================

def train(args):
    print("=" * 60)
    print("한국형 번아웃 감정 분류 모델 학습")
    print("=" * 60)
    
    # 디바이스 설정
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"\nDevice: {device}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
    
    # 토크나이저 로드
    print(f"\nLoading tokenizer: {MODEL_NAME}")
    tokenizer = ElectraTokenizer.from_pretrained(MODEL_NAME)
    
    # 데이터셋 로드
    print("\nLoading datasets...")
    train_dataset = BurnoutDataset(args.train_path, tokenizer, args.max_length)
    val_dataset = BurnoutDataset(args.val_path, tokenizer, args.max_length)
    
    # 모델 로드
    print(f"\nLoading model: {MODEL_NAME}")
    model = ElectraForSequenceClassification.from_pretrained(
        MODEL_NAME,
        num_labels=4,
        id2label=ID2LABEL,
        label2id=LABEL2ID
    )
    model.to(device)
    
    # 학습 인자 설정
    training_args = TrainingArguments(
        output_dir=args.output_dir,
        num_train_epochs=args.epochs,
        per_device_train_batch_size=args.batch_size,
        per_device_eval_batch_size=args.batch_size * 2,
        learning_rate=args.learning_rate,
        weight_decay=0.01,
        warmup_ratio=0.1,
        
        # 평가 설정
        eval_strategy="epoch",
        save_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="f1_macro",
        greater_is_better=True,
        
        # 로깅
        logging_dir=f"{args.output_dir}/logs",
        logging_steps=100,
        report_to="none",
        
        # 기타
        seed=42,
        fp16=torch.cuda.is_available(),
        dataloader_num_workers=0,
        save_total_limit=2,
    )
    
    # Trainer 설정
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_dataset,
        eval_dataset=val_dataset,
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=3)]
    )
    
    # 학습
    print("\n" + "=" * 60)
    print("Starting training...")
    print("=" * 60)
    trainer.train()
    
    # 최종 평가
    print("\n" + "=" * 60)
    print("Final Evaluation")
    print("=" * 60)
    
    eval_results = trainer.evaluate()
    print(f"\nValidation Results:")
    for key, value in eval_results.items():
        print(f"  {key}: {value:.4f}")
    
    # 모델 저장
    final_model_path = f"{args.output_dir}/final_model"
    trainer.save_model(final_model_path)
    tokenizer.save_pretrained(final_model_path)
    print(f"\nModel saved to: {final_model_path}")
    
    # 테스트셋 평가 (있는 경우)
    if args.test_path and os.path.exists(args.test_path):
        print("\n" + "=" * 60)
        print("Test Set Evaluation")
        print("=" * 60)
        
        test_dataset = BurnoutDataset(args.test_path, tokenizer, args.max_length)
        test_results = trainer.evaluate(test_dataset)
        
        print(f"\nTest Results:")
        for key, value in test_results.items():
            print(f"  {key}: {value:.4f}")
        
        # 상세 분류 리포트
        predictions = trainer.predict(test_dataset)
        preds = np.argmax(predictions.predictions, axis=1)
        labels = predictions.label_ids
        
        print("\nClassification Report:")
        print(classification_report(
            labels, preds,
            target_names=list(LABEL2ID.keys()),
            digits=4
        ))
    
    print("\n" + "=" * 60)
    print("Training Complete!")
    print("=" * 60)
    
    return trainer


def main():
    parser = argparse.ArgumentParser(description='번아웃 감정 분류 모델 학습')
    
    # 데이터 경로
    parser.add_argument('--train_path', type=str, 
                        default='dataset/processed/train.csv',
                        help='학습 데이터 경로')
    parser.add_argument('--val_path', type=str,
                        default='dataset/processed/val.csv',
                        help='검증 데이터 경로')
    parser.add_argument('--test_path', type=str,
                        default='dataset/processed/test.csv',
                        help='테스트 데이터 경로')
    parser.add_argument('--output_dir', type=str,
                        default='outputs/burnout_model',
                        help='모델 출력 디렉토리')
    
    # 학습 하이퍼파라미터
    parser.add_argument('--epochs', type=int, default=5)
    parser.add_argument('--batch_size', type=int, default=32)
    parser.add_argument('--learning_rate', type=float, default=2e-5)
    parser.add_argument('--max_length', type=int, default=128)
    
    args = parser.parse_args()
    
    # 디렉토리 생성
    os.makedirs(args.output_dir, exist_ok=True)
    
    train(args)


if __name__ == "__main__":
    main()
