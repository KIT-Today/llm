# 한국형 번아웃 감정 분류 - 데이터셋 전처리 & 학습 가이드

## 📊 데이터셋 분석 결과

### 전처리 후 최종 데이터

| 카테고리 | 데이터 수 | 비율 |
|---------|----------|------|
| 부정적_대인관계 | 46,968 | 36.8% |
| 좌절_압박 | 31,001 | 24.3% |
| 정서적_고갈 | 30,210 | 23.7% |
| 자기비하 | 19,449 | 15.2% |
| **합계** | **127,628** | 100% |

---

## 🚀 사용 방법

### 1단계: 데이터셋 전처리

```bash
python preprocess_dataset.py --data_dir "D:\Programming\Projects\Burnout\dataset" --output_dir "D:\Programming\Projects\Burnout\dataset\processed"
```

**생성되는 파일:**
```
dataset/processed/
├── burnout_all.csv      # 전체 데이터
├── burnout_dataset.csv  # 간소화 버전 (text, label만)
├── train.csv            # 학습용 (80%)
├── val.csv              # 검증용 (10%)
└── test.csv             # 테스트용 (10%)
```

### 2단계: 모델 학습

```bash
python train.py \
  --train_path "dataset/processed/train.csv" \
  --val_path "dataset/processed/val.csv" \
  --test_path "dataset/processed/test.csv" \
  --output_dir "outputs/burnout_model" \
  --epochs 5 \
  --batch_size 32 \
  --learning_rate 2e-5
```

**학습 결과 저장 위치:**
```
outputs/burnout_model/
├── final_model/         # 최종 모델
│   ├── config.json
│   ├── pytorch_model.bin
│   └── tokenizer files
└── logs/                # 학습 로그
```

### 3단계: 모델 사용

```python
from model import BurnoutClassifier

# 학습된 모델 로드
classifier = BurnoutClassifier("outputs/burnout_model/final_model")

# 예측
result = classifier.predict("오늘도 야근이다. 너무 지친다.")
print(result)
# {'label': '정서적_고갈', 'confidence': 0.85, 'description': '...'}

# 일기 심층 분석
analysis = classifier.analyze_diary("팀장이 또 나한테만 일을 시켜서 화가 난다.")
print(analysis)
# {'primary_emotion': '부정적_대인관계', 'burnout_risk_score': 0.45, ...}
```

---

## 📁 파일 구조

```
Burnout/
├── dataset/
│   ├── 018.감성대화/                    # AI Hub 원본
│   ├── 한국어 감정 정보가 포함된.../    # AI Hub 원본  
│   └── processed/                       # 전처리 결과
│       ├── train.csv
│       ├── val.csv
│       └── test.csv
├── preprocess_dataset.py    # 전처리 스크립트
├── train.py                 # 학습 스크립트
├── model.py                 # 모델 클래스
├── pipeline.py              # STT + 분류 파이프라인
├── server.py                # FastAPI 서버
└── outputs/
    └── burnout_model/       # 학습된 모델
```

---

## ⚙️ 감정 코드 매핑

### 감성대화 말뭉치 (60개 → 4개)

```
정서적_고갈: E20, E21, E22, E23, E24, E25, E40, E41, E45, E53, E58
좌절_압박:   E12, E13, E16, E17, E27, E28, E29, E30, E31, E32, E35, E50
부정적_대인관계: E10, E11, E14, E15, E18, E19, E33, E34, E38, E42~E48, E51, E52
자기비하:   E26, E36, E39, E49, E54, E55, E56, E57

제외 (긍정): E60~E69
```

### 연속적 대화 (7개 → 4개)

```
슬픔 → 정서적_고갈
공포 → 좌절_압박
분노 → 부정적_대인관계
혐오 → 부정적_대인관계

제외: 행복, 중립, 놀람
```

---

## 💡 학습 팁

1. **GPU 권장**: RTX 3060 이상, VRAM 8GB+
2. **배치 사이즈 조정**: VRAM 부족시 16으로 낮추기
3. **Early Stopping**: 기본 patience=3으로 과적합 방지
4. **예상 학습 시간**: GPU 기준 약 2-3시간

---

## 📈 예상 성능

| 메트릭 | 목표치 |
|--------|--------|
| Accuracy | 75-80% |
| F1 (macro) | 72-78% |
| F1 (weighted) | 75-80% |

---

## 🔧 트러블슈팅

### CUDA out of memory
```bash
python train.py --batch_size 16  # 배치 사이즈 감소
```

### 토크나이저 오류
```bash
pip install transformers==4.35.0 --upgrade
```

### 한글 인코딩 오류
CSV 파일은 `utf-8-sig`로 저장됨. Excel에서 열 때 인코딩 확인.
