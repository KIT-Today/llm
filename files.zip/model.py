"""
한국형 번아웃 감정 분류 모델
- 학습된 모델 로드 또는 사전학습 모델 사용
"""

import torch
import torch.nn as nn
from transformers import ElectraTokenizer, ElectraForSequenceClassification
from typing import Dict, List, Tuple, Optional
import os


# 기본 설정
DEFAULT_MODEL_NAME = "monologg/koelectra-base-v3-discriminator"

LABEL2ID = {
    "정서적_고갈": 0,
    "좌절_압박": 1,
    "부정적_대인관계": 2,
    "자기비하": 3
}

ID2LABEL = {v: k for k, v in LABEL2ID.items()}

# 카테고리별 설명
CATEGORY_DESCRIPTIONS = {
    "정서적_고갈": "감정적으로 지치고 소진된 상태. 무기력함, 우울감, 의욕 상실 등이 나타남",
    "좌절_압박": "업무나 상황에 대한 불안, 초조함, 압박감을 느끼는 상태",
    "부정적_대인관계": "직장 내 인간관계에서 갈등, 분노, 좌절을 경험하는 상태",
    "자기비하": "자신에 대한 부정적 평가, 열등감, 자책감을 느끼는 상태"
}


class BurnoutClassifier:
    """한국형 번아웃 감정 분류기"""
    
    def __init__(
        self,
        model_path: Optional[str] = None,
        device: Optional[str] = None
    ):
        """
        Args:
            model_path: 학습된 모델 경로 (없으면 사전학습 모델 사용)
            device: 'cuda' or 'cpu' (None이면 자동 감지)
        """
        # 디바이스 설정
        if device is None:
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        else:
            self.device = torch.device(device)
        
        # 모델 로드
        if model_path and os.path.exists(model_path):
            print(f"Loading trained model from: {model_path}")
            self.tokenizer = ElectraTokenizer.from_pretrained(model_path)
            self.model = ElectraForSequenceClassification.from_pretrained(model_path)
            self.is_trained = True
        else:
            print(f"Loading pretrained model: {DEFAULT_MODEL_NAME}")
            print("⚠️  경고: 파인튜닝되지 않은 모델입니다. 정확도가 낮을 수 있습니다.")
            self.tokenizer = ElectraTokenizer.from_pretrained(DEFAULT_MODEL_NAME)
            self.model = ElectraForSequenceClassification.from_pretrained(
                DEFAULT_MODEL_NAME,
                num_labels=4,
                id2label=ID2LABEL,
                label2id=LABEL2ID
            )
            self.is_trained = False
        
        self.model.to(self.device)
        self.model.eval()
        
        print(f"Model loaded on: {self.device}")
    
    def predict(
        self,
        text: str,
        return_probs: bool = False
    ) -> Dict:
        """
        단일 텍스트 감정 분류
        
        Args:
            text: 입력 텍스트
            return_probs: 전체 확률 분포 반환 여부
        
        Returns:
            {
                'label': 예측 라벨,
                'confidence': 신뢰도,
                'description': 카테고리 설명,
                'probabilities': {라벨: 확률} (return_probs=True일 때)
            }
        """
        # 토크나이징
        inputs = self.tokenizer(
            text,
            max_length=128,
            padding='max_length',
            truncation=True,
            return_tensors='pt'
        )
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        # 추론
        with torch.no_grad():
            outputs = self.model(**inputs)
            logits = outputs.logits
            probs = torch.softmax(logits, dim=-1)
        
        # 결과 추출
        pred_id = torch.argmax(probs, dim=-1).item()
        confidence = probs[0][pred_id].item()
        label = ID2LABEL[pred_id]
        
        result = {
            'label': label,
            'confidence': round(confidence, 4),
            'description': CATEGORY_DESCRIPTIONS[label]
        }
        
        if return_probs:
            result['probabilities'] = {
                ID2LABEL[i]: round(probs[0][i].item(), 4)
                for i in range(4)
            }
        
        return result
    
    def predict_batch(
        self,
        texts: List[str],
        batch_size: int = 32
    ) -> List[Dict]:
        """
        배치 텍스트 감정 분류
        
        Args:
            texts: 입력 텍스트 리스트
            batch_size: 배치 크기
        
        Returns:
            예측 결과 리스트
        """
        results = []
        
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            
            # 토크나이징
            inputs = self.tokenizer(
                batch_texts,
                max_length=128,
                padding=True,
                truncation=True,
                return_tensors='pt'
            )
            inputs = {k: v.to(self.device) for k, v in inputs.items()}
            
            # 추론
            with torch.no_grad():
                outputs = self.model(**inputs)
                logits = outputs.logits
                probs = torch.softmax(logits, dim=-1)
            
            # 결과 추출
            pred_ids = torch.argmax(probs, dim=-1).cpu().numpy()
            confidences = probs.max(dim=-1).values.cpu().numpy()
            
            for pred_id, conf in zip(pred_ids, confidences):
                label = ID2LABEL[pred_id]
                results.append({
                    'label': label,
                    'confidence': round(float(conf), 4),
                    'description': CATEGORY_DESCRIPTIONS[label]
                })
        
        return results
    
    def analyze_diary(self, text: str) -> Dict:
        """
        일기 텍스트 심층 분석
        
        Args:
            text: 일기 텍스트
        
        Returns:
            분석 결과 딕셔너리
        """
        result = self.predict(text, return_probs=True)
        
        # 번아웃 위험도 계산 (정서적_고갈 + 자기비하 가중치 높게)
        probs = result['probabilities']
        burnout_risk = (
            probs['정서적_고갈'] * 0.35 +
            probs['자기비하'] * 0.30 +
            probs['좌절_압박'] * 0.20 +
            probs['부정적_대인관계'] * 0.15
        )
        
        # 위험 수준 판정
        if burnout_risk >= 0.7:
            risk_level = "높음"
            recommendation = "전문가 상담을 권장합니다. 충분한 휴식이 필요합니다."
        elif burnout_risk >= 0.4:
            risk_level = "중간"
            recommendation = "스트레스 관리에 신경 쓰세요. 규칙적인 휴식을 취하세요."
        else:
            risk_level = "낮음"
            recommendation = "현재 상태가 양호합니다. 꾸준한 자기 관리를 유지하세요."
        
        return {
            'primary_emotion': result['label'],
            'confidence': result['confidence'],
            'description': result['description'],
            'all_probabilities': result['probabilities'],
            'burnout_risk_score': round(burnout_risk, 4),
            'risk_level': risk_level,
            'recommendation': recommendation
        }


# 편의 함수
_classifier_instance = None

def get_classifier(model_path: Optional[str] = None) -> BurnoutClassifier:
    """싱글톤 분류기 인스턴스 반환"""
    global _classifier_instance
    if _classifier_instance is None:
        _classifier_instance = BurnoutClassifier(model_path)
    return _classifier_instance


def classify(text: str, model_path: Optional[str] = None) -> Dict:
    """간편 분류 함수"""
    classifier = get_classifier(model_path)
    return classifier.predict(text, return_probs=True)


# 테스트
if __name__ == "__main__":
    # 모델 로드 (학습된 모델 경로 지정)
    # classifier = BurnoutClassifier("outputs/burnout_model/final_model")
    classifier = BurnoutClassifier()  # 사전학습 모델
    
    # 테스트 문장
    test_texts = [
        "오늘도 야근이다. 일이 끝나질 않아서 너무 지친다.",
        "팀장이 또 나한테만 일을 몰아줬어. 진짜 화가 난다.",
        "면접 결과가 나올 때까지 너무 불안해서 잠이 안 와.",
        "나는 왜 이렇게 못할까. 다른 사람들은 다 잘하는데.",
    ]
    
    print("\n" + "=" * 60)
    print("테스트 결과")
    print("=" * 60)
    
    for text in test_texts:
        result = classifier.analyze_diary(text)
        print(f"\n입력: {text}")
        print(f"  → 감정: {result['primary_emotion']} ({result['confidence']:.1%})")
        print(f"  → 번아웃 위험: {result['risk_level']} ({result['burnout_risk_score']:.1%})")
        print(f"  → 권고: {result['recommendation']}")
